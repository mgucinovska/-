package com.project.finki.enumerations;

public enum CartStatus {
    CREATED, CANCELED, FINISHED
}
