package com.project.finki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinkiApplicationTests {

	@Test
	void contextLoads() {
	}

}
