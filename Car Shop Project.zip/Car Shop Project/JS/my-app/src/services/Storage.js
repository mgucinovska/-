
module.exports = {

    setToken: function(token) {
        localStorage.setItem("token", token);
    },

    getToken: function() {
      return localStorage.getItem("token");
    },

    removeToken: function() {
        localStorage.removeItem('token');
    },

    parsedToken: function() {
        let token = this.getToken();

        if (token) {
            var base64Url = token.split('.')[1];
            var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
            var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
            }).join(''));
        
            return JSON.parse(jsonPayload);
        }
    },

    getAuthority: function () {
        let parsedToken = this.parsedToken();
        let authority = parsedToken.Authorities[0]["authority"];

        return authority;
    },

    getPublicKey: function () {
        return "pk_test_51HgC0jHdhsY202KRyy8DtKmaZ464xAkBExb1NejVuqjzTqAVyRGAb3kRFsmHzMqZjUnLtHRpO4XHNmtgOlPkfyYD00e6sTS3iA";
    }

}
