import axios from "axios";
import Storage from "./Storage";

const CAR_API_BASE_URL = "http://localhost:8080/api/v1/cars";

let token = Storage.getToken();

class CarService {
    //povik za zemanje na site koli
    getCars(){
        return axios.get(CAR_API_BASE_URL,
    {
            headers: {
                Authorization: "Bearer " + token
            }
        });
    }

    //povik za dodavanje na kola
    addCar(data) {
        return axios.post(CAR_API_BASE_URL, data, {
            headers: {
                Authorization: "Bearer " + token,
                "Content-Type": "multipart/form-data"
            },
        });
    }

    //zemanje na podatoci za kola spored id
    getCarById(id) {
        return axios.get(CAR_API_BASE_URL + '/' + id, {
            headers: {
                Authorization: "Bearer " + token
            },
        });
    }

    //zemanje na site koli spored proizvoditel
    getCarsByManufacturerId(id) {
        return axios.get(CAR_API_BASE_URL + '/manufacturer/' + id, {
            headers: {
                Authorization: "Bearer " + token
            },
        });
    }

    //menuvanje na podatoci za kola
    editCar(car, id) {
        return axios.put(CAR_API_BASE_URL + '/' + id, car, {
            headers: {
                Authorization: "Bearer " + token
            },
        });
    }

    //brisenje na kola
    deleteCar(id) {
        return axios.delete(CAR_API_BASE_URL + '/' + id, {
            headers: {
                Authorization: "Bearer " + token
            },
        });
    }

}

export default new CarService();