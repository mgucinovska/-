import axios from "axios";
import Storage from "./Storage";

const MANUFACTURER_API_BASE_URL = "http://localhost:8080/api/v1/manufacturers";

let token = Storage.getToken();

class ManufacturerService {

    //zemanje na site proizvoditeli
    getManufacturers() {
        return axios.get(MANUFACTURER_API_BASE_URL,
        {
            headers: {
                Authorization: "Bearer " + token
            }
        });
    }

    //dodavanje na proizvoditel
    addManufacturer(data) {
        return axios.post(MANUFACTURER_API_BASE_URL, data, {
            headers: {
                Authorization: "Bearer " + token,
                "Content-Type": "multipart/form-data"
            }
        })
    }

    //brisenje na proizvoditel
    removeManufacturer(id) {
        return axios.delete(MANUFACTURER_API_BASE_URL + "/" + id,
        {
            headers: {
                Authorization: "Bearer " + token
            },
        });
    }
    
}

export default new ManufacturerService();