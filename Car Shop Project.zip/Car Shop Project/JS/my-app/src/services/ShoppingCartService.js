import axios from "axios";
import Storage from "./Storage";

const CART_SHOP_API_BASE_URL = "http://localhost:8080/api/v1/shopping-carts";

let token = Storage.getToken();

class ShoppingCartService {

    //zemanje podatoci od kosnickata na korisnikot
    getUserShoppingCart(){
        return axios.get(CART_SHOP_API_BASE_URL + "/findByUsername", {
            headers: {
                Authorization: "Bearer " + token
            }
        });
    }

    //kreiranje na kosnicka
    createShoppingCart() {
        return axios.post(CART_SHOP_API_BASE_URL , null,  {
            headers: {
                Authorization: "Bearer " + token
            }
        });
    }

    //dodavanje na kola vo kosnicka
    addToShoppingCart(id, quantity) {
        return axios.put(CART_SHOP_API_BASE_URL  + "/addCar/" + id, quantity,  {
            headers: {
                Authorization: "Bearer " + token
            }
        });
    }

    //brisenje na kola od kosnicka
    removeFromShoppingCart(id){
        return axios.delete(CART_SHOP_API_BASE_URL + "/" + id, {
            headers: {
                Authorization: "Bearer " + token
            }
        });
    }

    //kupuvanje na site koli od kosnicka + plakanja
    buyCars(newForm) {
        return axios.put(CART_SHOP_API_BASE_URL + "/buyCars", newForm, {
            headers: {
                Authorization: "Bearer " + token
            }
        });
    }

}

export default new ShoppingCartService();