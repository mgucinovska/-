import React, {Component} from 'react';
import CarService from "../services/CarService";
import Storage from '../services/Storage';
import ShoppingCartService from "../services/ShoppingCartService";

class ListCarComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            cars: [],
            quantity: 0,
            authority: null
        }

        this.addCar = this.addCar.bind(this);
        this.editCar = this.editCar.bind(this);
        this.addToCart = this.addToCart.bind(this);
        this.deleteCar = this.deleteCar.bind(this);
        this.viewCar = this.viewCar.bind(this);
        this.viewManufacturers = this.viewManufacturers.bind(this);
        this.changeQuantity = this.changeQuantity.bind(this);
    }

    componentDidMount() {
        let token = Storage.getToken();

        if (!token) {
            this.props.history.push('/login');
        } else {

            let id = parseInt(this.props.location.pathname.replace("/cars/", ""));

            if(id) {
                CarService.getCarsByManufacturerId(id).then((res) => {
                    this.setState({cars: res.data});
                });
                
            } else {
                CarService.getCars().then((res) => {
                    this.setState({cars: res.data});
                });
            }

            let authority = Storage.getAuthority();
            this.setState({authority: authority});
        }

    }

    addCar() {
        this.props.history.push('/add-car');
    }

    viewManufacturers() {
        this.props.history.push('/');
    }

    editCar(id) {
        this.props.history.push(`/edit-car/${id}`);
    }

    addToCart(id) {

        if (this.state.quantity < 1) {
            alert("You need to enter quantity bigger than 0");
            return false;
        }

        let newForm = new FormData();

        newForm.append("quantity", this.state.quantity)

        ShoppingCartService.addToShoppingCart(id, newForm).then(res => {
            if (res.data === "") {
                alert("The quantity you choose is bigger than quantity in the database");
                return false;
            } else {
                alert("Successfully added car in shopping cart ");
                window.location.href = window.location.href;
            }
        }).catch(error => {
            if (error.response.status === 412) {
                alert("Car is already in shopping cart");
                return false;
            }
            console.log(error);
        })
    }

    deleteCar(id) {
        CarService.deleteCar(id).then((res) =>{
            this.setState({cars: this.state.cars.filter(car => car.id !== id)});
        })
    }

    viewCar(id) {
        this.props.history.push(`/view-car/${id}`);
    }

    changeQuantity(event) {
        let value = +event.target.value;

        this.setState({quantity: value});
    }

    render() {
        return (
            <div>
                <h2 className="text-center"> Cars List </h2>
                <div className="row">
                    {
                        this.state.authority === "ADMIN" && <button className="btn btn-primary" onClick={this.addCar}> Add Car </button>
                    }
                    <button style={{marginLeft: "10px"}} className="btn btn-primary" onClick={this.viewManufacturers}> View Manufacturers </button>
                </div>
                &nbsp;
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Model</th>
                                <th>Manufacturer</th>
                                <th>Year</th>
                                <th>Price</th>
                                <th>Color</th>
                                <th>Quantity</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.cars.map(
                                    car =>
                                        <tr key={car.id}>
                                            <td><a href="" onClick={() => this.viewCar(car.id)}>{car.name}</a></td>
                                            <td>{car.manufacturer.name}</td>
                                            <td>{car.year}</td>
                                            <td>{car.price.toLocaleString('en-US', {style: 'currency', currency:'EUR'})}</td>
                                            <td><div style={{width: "20px", height: "20px", backgroundColor: car.color, display: "inline-block"}}></div></td>
                                            <td>{car.numberOfCopies}</td>
                                            <td>
                                                <input type="number" id={car.id} style={{width: "50px"}} onChange={this.changeQuantity}/>
                                                <button style={{marginLeft: "5px"}} onClick={() => this.addToCart(car.id)} className="btn btn-success">Add to Cart</button>
                                                {
                                                    this.state.authority === "ADMIN" && <button style={{marginLeft: "10px"}} onClick={() => this.editCar(car.id)} className="btn btn-info">Edit</button>

                                                }
                                                {
                                                    this.state.authority === "ADMIN" && <button style={{marginLeft: "10px"}} onClick={() => this.deleteCar(car.id)} className="btn btn-danger">Delete</button>
                                                }
                                             </td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}

export default ListCarComponent;