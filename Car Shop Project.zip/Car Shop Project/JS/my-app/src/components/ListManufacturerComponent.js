import React, {Component} from 'react';
import ManufacturerService from '../services/ManufacturerService';
import Storage from '../services/Storage';
import ShoppingCartService from "../services/ShoppingCartService";

class ListManufacturerComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            manufacturers: [],
            authority: null
        }

        this.addManufacturer = this.addManufacturer.bind(this);
        this.viewCars = this.viewCars.bind(this);
        this.viewAllCars = this.viewAllCars.bind(this);
        this.removeManufacturer = this.removeManufacturer.bind(this);
    }

    addManufacturer() {
        this.props.history.push('/add-manufacturer');
    }

    viewCars(id) {
        this.props.history.push(`/cars/${id}`);
    }
    
    viewAllCars() {
        this.props.history.push('/cars');
    }

    removeManufacturer(id) {
        ManufacturerService.removeManufacturer(id).then((res) => {
            this.componentDidMount();
        });
    }

    componentDidMount() {
        let token = Storage.getToken();

        if (!token) {
            this.props.history.push('/login');
        } else {
            ShoppingCartService.getUserShoppingCart().then((res) => {
                if (res.data === "") {
                    ShoppingCartService.createShoppingCart().then(resCreate => {

                    }).catch(error => {
                        console.log(error);
                    });
                }
            }).catch(error => {
                console.log(error);
            });

            ManufacturerService.getManufacturers().then((res) => {
                this.setState({manufacturers: res.data});
            }).catch(error => {
                console.log(error);
                });

            let authority = Storage.getAuthority();
            this.setState({authority: authority});
        }
        
    }

    render() {
        return (
            <div>
                <h2 className="text-center"> Manufacturers List </h2>
                <div className="row">
                    {
                        this.state.authority === "ADMIN" && <button className="btn btn-primary" onClick={() => this.addManufacturer()}> Add Manufacturer </button>
                    }
                    &nbsp;
                    <button className="btn btn-primary" onClick={() => this.viewAllCars()}> View all Cars </button>
                </div>
                &nbsp;
                <div className="row">
                    <div className="card-deck row">
                        {
                            this.state.manufacturers.map(
                                manufacturer => 
                                    <div className="card p-4" key={manufacturer.id}>
                                        <img className="card-img-top" alt="" width="100" height="100" src={manufacturer.image} onClick={() => this.viewCars(manufacturer.id)} />
                                        <div className="card-body">
                                            <h5 className="card-title">{manufacturer.name}</h5>
                                        </div>
                                        {
                                            this.state.authority === "ADMIN" && <button className="btn btn-danger" onClick={() => this.removeManufacturer(manufacturer.id)}>Remove</button>
                                        }
                                    </div>
                            )
                        }
                    </div>                    
                </div>
            </div>
        );
    }
}

export default ListManufacturerComponent;