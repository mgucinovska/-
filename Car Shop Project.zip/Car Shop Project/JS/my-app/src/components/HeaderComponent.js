import React, {Component} from 'react';

class HeaderComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {

        }

    }

    render() {
        return (
            <div>
                <header>
                    <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                        <div>
                            <a href="/" className="navbar-brand"> Car Shop </a>
                            {
                                window.location.pathname !== "/login" && <a href="/login" className="btn btn-danger"> Logout </a>
                            }
                            {
                                window.location.pathname !== "/login" && <a href="/shopping-cart" className="btn btn-light" style={{marginLeft: "10px"}}> Shopping Cart </a>
                            }

                        </div>
                    </nav>
                </header>
            </div>
        );
    }
}

export default HeaderComponent;