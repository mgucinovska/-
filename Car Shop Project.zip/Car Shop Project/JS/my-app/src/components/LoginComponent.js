import React, {Component} from 'react';
import axios from 'axios';
import Storage from '../services/Storage';

class LoginComponent extends Component {
    constructor(pros) {
        super(pros);

        this.state = {
            username: "",
            password: ""
        }

        this.loginUser = this.loginUser.bind(this);
        this.username = this.username.bind(this);
        this.password = this.password.bind(this);
    }

    componentDidMount() {
        Storage.removeToken();
    }

    loginUser = (e) => {
        e.preventDefault();

        if (this.state.username === "" || this.state.password === "") {
            alert("Username and password are required");
            return false;
        }
        
        let data = {username: this.state.username, password: this.state.password};

        axios.post("http://localhost:8080/authenticate", data).then((res) => {
            console.log(res);
            Storage.setToken(res.data.jwt);
            window.location.href = "/";
        }).catch(error => {
            alert("Wrong username or password");
            return false;
        });
    }

    username = (e) => {
        this.setState({username: e.target.value});
    }

    password = (e) => {
        this.setState({password: e.target.value});
    }
    
    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-3 mt-3">
                            <h3 className="text-center">Login</h3>
                            <div className="card-body">
                                <form>
                                    <div className="form-group text-left">
                                        <label> Username </label>
                                        <input placeholder="Username" name="username" className="form-control"
                                               value={this.state.username} onChange={this.username}/>
                                    </div>
                                    <div className="form-group text-left">
                                        <label> Password </label>
                                        <input placeholder="Password" type="password" name="password" className="form-control"
                                               value={this.state.password} onChange={this.password}/>
                                    </div>

                                    <button className="btn btn-success" onClick={this.loginUser}> Login </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default LoginComponent;