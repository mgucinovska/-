import React, {Component} from 'react';
import ShoppingCartService from "../services/ShoppingCartService";
import Storage from '../services/Storage';
import Modal from 'react-bootstrap/Modal'



class ShoppingCartComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data: [],
            total: 0,
            show: false,
            cardNumber: "",
            expMonth: "",
            expYear: "",
            cvc: "",
        }

        this.removeCar = this.removeCar.bind(this);
        this.buyCars = this.buyCars.bind(this);
        this.viewCar = this.viewCar.bind(this);
        this.viewAllCars = this.viewAllCars.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleShow = this.handleShow.bind(this);
        this.cardNumber = this.cardNumber.bind(this);
        this.expMonth = this.expMonth.bind(this);
        this.expYear = this.expYear.bind(this);
        this.cvc = this.cvc.bind(this);
    }

    componentDidMount() {
        let token = Storage.getToken();

        if (!token) {
            this.props.history.push('/login');
        } else {
            let total_price = 0;
            ShoppingCartService.getUserShoppingCart().then((res) => {
                this.setState({data: res.data.orderCars});

                this.state.data.forEach(function (car){
                    total_price += (car.quantity * car.carPrice);
                });

                this.setState({total: total_price});
             });


        }

    }

    removeCar(id) {
        ShoppingCartService.removeFromShoppingCart(id).then((res) => {
           this.componentDidMount();
        });
    }

    viewCar(id) {
        this.props.history.push(`/view-car/${id}`);
    }

    buyCars() {
        if (this.state.data.length === 0) {
            alert("Your shopping cart is empty");
            return false;
        } else {
            let currentObj = this;
            let pkKey = Storage.getPublicKey();
            let newForm = new FormData();

            if (this.state.cardNumber === "" ||
                this.state.expMonth === "" ||
                this.state.expYear === "" ||
                this.state.cvc === "") {
                alert("All fields are required!");
                return false;
            }

            if (this.state.cardNumber.length !== 16) {
                alert("Card number need to have 16 numbers");
                return false;
            }

            if (this.state.expMonth > 12) {
                alert("Expiration Month need to be equal or less than 12");
                return false;
            }

            if (this.state.expYear < 2020) {
                alert("Expiration Year need to be equal or greater than 2020");
                return false;
            }

            if (this.state.cvc.length !== 3) {
                alert("CVC need to be 3 numbers");
                return false;
            }

            newForm.append("description", "Test pay");
            newForm.append("amount", this.state.total);
            newForm.append("currency", "EUR");
            newForm.append("stripeToken", pkKey);
            newForm.append("cardNumber", this.state.cardNumber);
            newForm.append("expMonth", this.state.expMonth);
            newForm.append("expYear", this.state.expYear);
            newForm.append("cvc", this.state.cvc);

            ShoppingCartService.buyCars(newForm).then((res) => {
                if (res.data === "") {
                    alert("Тhere is not enough quantity");
                    return false;
                }

                var counter = 0;
                this.state.data.forEach(function (car) {
                    ShoppingCartService.removeFromShoppingCart(car.id).then((res) =>{
                        counter ++;

                        if (currentObj.state.data.length ===  counter) {
                            alert("Successfully purchased");
                            window.location.href = "/cars";
                        }
                    })
                });
            }).catch(error => {
                if (error.response.status === 412) {
                    alert("Problem with pay");
                    return false;
                }
            });


        }
    }

    viewAllCars() {
        this.props.history.push('/cars');
    }

    handleClose() {
        this.setState({show: false});
    }

    handleShow() {
        if (this.state.data.length === 0) {
            alert("Your shopping cart is empty");
            return false;
        } else {
            this.setState({show: true});
        }
    }

    cardNumber(event) {
        this.setState({cardNumber: event.target.value})
    }

    expMonth(event) {
        this.setState({expMonth: event.target.value})
    }

    expYear(event) {
        this.setState({expYear: event.target.value})
    }

    cvc(event) {
        this.setState({cvc: event.target.value})
    }

    render() {
        return (
            <div>
                <h2 className="text-center"> Shopping Cart List </h2>
                <br/>
                <div className="row">
                    <button className="btn btn-primary" onClick={() => this.viewAllCars()}> View all Cars </button>
                </div>
                <br/>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Model</th>
                                <th>Manufacturer</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.data.map(
                                    car =>
                                        <tr key={car.id}>
                                            <td><a href="" onClick={() => this.viewCar(car.carId)}>{car.carName}</a></td>
                                            <td>{car.manufacturerName}</td>
                                            <td>{car.quantity}</td>
                                            <td>{car.carPrice.toLocaleString('en-US', {style: 'currency', currency:'EUR'})}</td>
                                            <td>
                                                <button onClick={() => this.removeCar(car.id)} className="btn btn-danger">Delete</button>
                                            </td>
                                        </tr>
                                )
                            }
                            {
                                this.state.data.length > 0 && <tr>
                                    <td colSpan={3} style={{textAlign: "right"}}><b>Total: </b></td>
                                    <td>{this.state.total.toLocaleString('en-US', {style: 'currency', currency:'EUR'})}</td>
                                </tr>
                            }

                        </tbody>
                    </table>

                    <button onClick={() => this.handleShow()} className="btn btn-success">Checkout</button>
                </div>

                <Modal show={this.state.show} onHide={() => this.handleClose()}>
                    <Modal.Header closeButton>
                        <Modal.Title>Card Details</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="row">
                            <div className="form-group col-md-12 text-left">
                                <label> Card Number </label>
                                <input placeholder="Card Number" maxLength="16" name="cardNumber" className="form-control"
                                       value={this.state.cardNumber} onChange={this.cardNumber}/>
                            </div>
                            <div className="form-group col-md-4  text-left">
                                <label> Expiration month </label>
                                <input placeholder="Expiration month" maxLength="2" name="expMonth" className="form-control"
                                       value={this.state.expMonth} onChange={this.expMonth}/>
                            </div>
                            <div className="form-group col-md-4  text-left">
                                <label> Expiration year </label>
                                <input placeholder="Expiration year" maxLength="4" name="expYear" className="form-control"
                                       value={this.state.expYear} onChange={this.expYear}/>
                            </div>
                            <div className="form-group col-md-4  text-left">
                                <label> CVC </label>
                                <input placeholder="CVC" maxLength="3" name="cvc" className="form-control"
                                       value={this.state.cvc} onChange={this.cvc}/>
                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <button className="btn btn-danger" onClick={() => this.handleClose()}>
                            Close
                        </button>
                        <button className="btn btn-primary" onClick={() => this.buyCars()}>
                            Pay {this.state.total.toLocaleString('en-US', {style: 'currency', currency:'EUR'})}
                        </button>
                    </Modal.Footer>
                </Modal>
            </div>
        );
    }
}

export default ShoppingCartComponent;