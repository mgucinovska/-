import React, {Component} from 'react';
import Storage from '../services/Storage';
import ManufacturerService from "../services/ManufacturerService";

class CreateManufacturer extends Component {
    constructor(pros) {
        super(pros);

        this.state = {
            name: '',
            image: null
        }

        
        this.changeName = this.changeName.bind(this);
        this.changeImage = this.changeImage.bind(this);
        this.saveManufacturer = this.saveManufacturer.bind(this);

    }

    componentDidMount() {
        let token = Storage.getToken();

        if (!token) {
            this.props.history.push('/login');
        }
    }

    changeName(event) {
        this.setState({name: event.target.value});
    }

    changeImage(event) {
        this.setState({image: event.target.files[0]});
    }

    saveManufacturer(e) {
        e.preventDefault();
        let formData = new FormData();

        formData.append("name", this.state.name);
        formData.append("image", this.state.image);

        ManufacturerService.addManufacturer(formData).then((res) => {
            this.props.history.push('/');
        }).catch(error => {
            console.log(error);
        });

    }

    cancel() {
        this.props.history.push("/manufacturers");
    }

    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-3 mt-3">
                            <h3 className="text-center">Add Manufacturer</h3>
                            <div className="card-body">
                                <form>
                                    <div className="form-group text-left">
                                        <label> Name </label>
                                        <input placeholder="Name" name="name" className="form-control"
                                        value={this.state.name} onChange={this.changeName}/>
                                    </div>
                                    <div className="form-group text-left">
                                        <label> Image </label><br></br>
                                        <input placeholder="Image" type="file" name="image" onChange={this.changeImage}/>
                                    </div>

                                    <button className="btn btn-success" onClick={this.saveManufacturer}> Save </button>
                                    <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}> Cancel </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default CreateManufacturer;