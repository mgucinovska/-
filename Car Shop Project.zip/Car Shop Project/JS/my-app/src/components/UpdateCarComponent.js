import React, {Component} from 'react';
import CarService from "../services/CarService";
import Storage from '../services/Storage';

class UpdateCarComponent extends Component {
    constructor(pros) {
        super(pros);

        this.state = {
            id: this.props.match.params.id,
            name: '',
            manufacturerId: null,
            manufacturerName:'',
            year: '',
            price: '',
            color: '#000000',
            quantity: '',
            image: null,
            imageView: null,
            description: '',
            displayImage: "visible"
        }

        this.changeModel = this.changeModel.bind(this);
        this.changeManufacturer = this.changeManufacturer.bind(this);
        this.changeYear = this.changeYear.bind(this);
        this.changePrice = this.changePrice.bind(this);
        this.changeColor = this.changeColor.bind(this);
        this.changeQuantity = this.changeQuantity.bind(this);
        this.changeImage = this.changeImage.bind(this);
        this.changeDescription = this.changeDescription.bind(this);
        this.updateCar = this.updateCar.bind(this);
    }

    changeModel = (event) => {
        this.setState({name: event.target.value});
    }

    changeManufacturer = (event) => {
        this.setState({manufacturerId: +event.target.value});
    }

    changeYear = (event) => {
        this.setState({year: event.target.value});
    }

    changeColor = (event) => {
        this.setState({color: event.target.value});
    }

    changePrice = (event) => {
        this.setState({price: +event.target.value});
    }

    changeQuantity = (event) => {
        this.setState({quantity: +event.target.value});
    }

    changeImage = (event) => {
        this.setState({image: event.target.files[0], displayImage: "none"});
    }

    changeDescription = (event) => {
        this.setState({description: event.target.value});
    }

    updateCar = (e) => {
        e.preventDefault();

        let formData = new FormData();

        formData.append("name", this.state.name);
        formData.append("manufacturerId", this.state.manufacturerId);
        formData.append("year", this.state.year);
        formData.append("color", this.state.color);
        formData.append("price", this.state.price);
        formData.append("numberOfCopies", this.state.quantity);
        formData.append("image", this.state.image);
        formData.append("description", this.state.description);

        CarService.editCar(formData, this.state.id).then((res) => {
            this.props.history.push("/cars");
        });
    }

    cancel() {
        this.props.history.push("/cars");
    }

    componentDidMount() {
        let token = Storage.getToken();

        if (!token) {
            this.props.history.push('/login');
        } else {

            CarService.getCarById(this.state.id).then((res) =>{
            this.setState({
                    name: res.data.name,
                    manufacturerId: res.data.manufacturer.id,
                    manufacturerName: res.data.manufacturer.name,
                    year: res.data.year,
                    color: res.data.color,
                    price: res.data.price,
                    quantity: res.data.numberOfCopies,
                    imageView: res.data.image,
                    description: res.data.description
            })
            });
        }
    }


    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-12 offset-0 mt-3">
                            <h3 className="text-center">Edit Car</h3>
                            <div className="card-body">
                                <form className="row" encType="multipart/form-data">
                                    <div className="form-group col-md-6 text-left">
                                        <label> Model </label>
                                        <input placeholder="Model" name="model" className="form-control"
                                               value={this.state.name} onChange={this.changeModel}/>
                                    </div>
                                    <div className="form-group col-md-6  text-left">
                                        <label> Manufacturer </label>
                                        <select  name="manufacturer" disabled={true} className="form-control" onChange={this.changeManufacturer}>
                                            <option value={this.state.manufacturerId}>{this.state.manufacturerName}</option>
                                        </select>
                                    </div>
                                    <div className="form-group col-md-6  text-left">
                                        <label> Year </label>
                                        <input placeholder="Year" name="year" className="form-control"
                                               value={this.state.year} onChange={this.changeYear}/>
                                    </div>
                                    <div className="form-group col-md-6  text-left">
                                        <label> Price </label>
                                        <input placeholder="Price" type="number" name="price" className="form-control"
                                               value={this.state.price} onChange={this.changePrice}/>
                                    </div>
                                    <div className="form-group col-md-3   text-left">
                                        <label> Color </label>
                                        <input placeholder="Color" type="color" name="color" className="form-control"
                                               value={this.state.color} onChange={this.changeColor}/>
                                    </div>
                                    <div className="form-group col-md-6 offset-3  text-left">
                                        <label> Quantity </label>
                                        <input placeholder="Quantity" type="number" name="quantity" className="form-control"
                                               value={this.state.quantity} onChange={this.changeQuantity}/>
                                    </div>
                                    <div className="form-group col-md-6  text-left">
                                        <label> Image </label><br></br>
                                        <img style={{display: this.state.displayImage}} alt="img" src={this.state.imageView} width={200} height={100} /><br></br>
                                        <input placeholder="Image" type="file" name="image"
                                               onChange={this.changeImage}/>
                                    </div>
                                    <div className="form-group col-md-6  text-left">
                                        <label> Description </label>
                                        <textarea placeholder="Description" name="description" className="form-control"
                                                  value={this.state.description} onChange={this.changeDescription}/>
                                    </div>

                                    <button className="btn btn-success" onClick={this.updateCar}> Save </button>
                                    <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}> Cancel </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default UpdateCarComponent;