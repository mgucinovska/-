import React, {Component} from 'react';
import CarService from "../services/CarService";
import Storage from '../services/Storage';

class ViewCarComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            id: this.props.match.params.id,
            manufacturer: '',
            price: 0,
            car: {}
        }

        this.goBack = this.goBack.bind(this);
    }

    componentDidMount() {
        let token = Storage.getToken();

        if (!token) {
            this.props.history.push('/login');
        } else {
            CarService.getCarById(this.state.id).then((res) => {
            this.setState({car: res.data, manufacturer: res.data.manufacturer.name, price: res.data.price});
            });
        }
    }

    goBack() {
        this.props.history.goBack();
    }

    render() {
        return (
            <div>
                <div className="row">
                    <button className="btn btn-info mt-3" onClick={() => this.goBack()}>Back</button>
                </div>
                <div className="card col-md-6 offset-md-3 mt-3">
                    <h3 className="text-center"> Car Details </h3>
                    <div className="card-body">
                        <div className="row">
                            <div> <img src={this.state.car.image} alt="img"  width={200} height={100} /> </div>
                        </div>
                        <br></br>
                        <div className="row">
                            <label>Model: &nbsp;</label>
                            <div> {this.state.car.name} </div>
                        </div>
                        <div className="row">
                            <label>Manufacturer: &nbsp;</label>
                            <div> {this.state.manufacturer} </div>
                        </div>
                        <div className="row">
                            <label>Year: &nbsp;</label>
                            <div> {this.state.car.year} </div>
                        </div>
                        <div className="row">
                            <label>Price: &nbsp;</label>
                            <div> {this.state.price.toLocaleString('en-US', {style: 'currency', currency:'EUR'})} </div>
                        </div>
                        <div className="row">
                            <label>Color: &nbsp;</label>
                            <div><div style={{width: "20px", height: "20px", backgroundColor: this.state.car.color}}></div> </div>
                        </div>
                        <div className="row">
                            <label>Quantity: &nbsp;</label>
                            <div> {this.state.car.numberOfCopies} </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default ViewCarComponent;