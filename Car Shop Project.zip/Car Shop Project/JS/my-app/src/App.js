import React from 'react';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import ListCarComponent from './components/ListCarComponent';
import HeaderComponent from "./components/HeaderComponent";
import FooterComponent from "./components/FooterComponent";
import CreateCarComponent from "./components/CreateCarComponent";
import UpdateCarComponent from "./components/UpdateCarComponent";
import ViewCarComponent from "./components/ViewCarComponent";
import LoginComponent from "./components/LoginComponent";
import ListManufacturerComponent from './components/ListManufacturerComponent';
import CreateManufacturer from './components/CreateManufacturerComponent';
import ShoppingCartComponent from './components/ShoppingCartComponent';

function App() {
  return (
    <div className="App">
        <Router>
              <HeaderComponent/>
                  <div className="container">
                      <Switch>
                          <Route path="/" exact component={ListManufacturerComponent}></Route>
                          <Route path="/cars" component={ListCarComponent}></Route>
                          <Route path="/cars/:id" component={ListCarComponent}></Route>
                          <Route path="/add-car" component={CreateCarComponent}></Route>
                          <Route path="/edit-car/:id" component={UpdateCarComponent}></Route>
                          <Route path="/view-car/:id" component={ViewCarComponent}></Route>
                          <Route path="/manufacturers" component={ListManufacturerComponent}></Route>
                          <Route path="/add-manufacturer" component={CreateManufacturer}></Route>
                          <Route path="/shopping-cart" component={ShoppingCartComponent}></Route>
                          <Route path="/login" component={LoginComponent}></Route>
                      </Switch>
                  </div>
              <FooterComponent/>
        </Router>
    </div>
  );
}

export default App;
